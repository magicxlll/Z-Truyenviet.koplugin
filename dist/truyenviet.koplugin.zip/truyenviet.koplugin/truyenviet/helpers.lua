local socket_url = require("socket.url")
local ko_util = require("util")

local Util = {}

function Util.urlEncode(str)
    if not str then return "" end
    str = tostring(str)
    return str:gsub("([^%w%-%_%.%~])", function(c)
        return string.format("%%%02X", string.byte(c))
    end)
end

ko_util.urlEncode = Util.urlEncode

local VIETNAMESE_ASCII = {
    ["à"] = "a", ["á"] = "a", ["ạ"] = "a", ["ả"] = "a", ["ã"] = "a",
    ["â"] = "a", ["ầ"] = "a", ["ấ"] = "a", ["ậ"] = "a", ["ẩ"] = "a", ["ẫ"] = "a",
    ["ă"] = "a", ["ằ"] = "a", ["ắ"] = "a", ["ặ"] = "a", ["ẳ"] = "a", ["ẵ"] = "a",
    ["è"] = "e", ["é"] = "e", ["ẹ"] = "e", ["ẻ"] = "e", ["ẽ"] = "e",
    ["ê"] = "e", ["ề"] = "e", ["ế"] = "e", ["ệ"] = "e", ["ể"] = "e", ["ễ"] = "e",
    ["ì"] = "i", ["í"] = "i", ["ị"] = "i", ["ỉ"] = "i", ["ĩ"] = "i",
    ["ò"] = "o", ["ó"] = "o", ["ọ"] = "o", ["ỏ"] = "o", ["õ"] = "o",
    ["ô"] = "o", ["ồ"] = "o", ["ố"] = "o", ["ộ"] = "o", ["ổ"] = "o", ["ỗ"] = "o",
    ["ơ"] = "o", ["ờ"] = "o", ["ớ"] = "o", ["ợ"] = "o", ["ở"] = "o", ["ỡ"] = "o",
    ["ù"] = "u", ["ú"] = "u", ["ụ"] = "u", ["ủ"] = "u", ["ũ"] = "u",
    ["ư"] = "u", ["ừ"] = "u", ["ứ"] = "u", ["ự"] = "u", ["ử"] = "u", ["ữ"] = "u",
    ["ỳ"] = "y", ["ý"] = "y", ["ỵ"] = "y", ["ỷ"] = "y", ["ỹ"] = "y",
    ["đ"] = "d",
    ["À"] = "a", ["Á"] = "a", ["Ạ"] = "a", ["Ả"] = "a", ["Ã"] = "a",
    ["Â"] = "a", ["Ầ"] = "a", ["Ấ"] = "a", ["Ậ"] = "a", ["Ẩ"] = "a", ["Ẫ"] = "a",
    ["Ă"] = "a", ["Ằ"] = "a", ["Ắ"] = "a", ["Ặ"] = "a", ["Ẳ"] = "a", ["Ẵ"] = "a",
    ["È"] = "e", ["É"] = "e", ["Ẹ"] = "e", ["Ẻ"] = "e", ["Ẽ"] = "e",
    ["Ê"] = "e", ["Ề"] = "e", ["Ế"] = "e", ["Ệ"] = "e", ["Ể"] = "e", ["Ễ"] = "e",
    ["Ì"] = "i", ["Í"] = "i", ["Ị"] = "i", ["Ỉ"] = "i", ["Ĩ"] = "i",
    ["Ò"] = "o", ["Ó"] = "o", ["Ọ"] = "o", ["Ỏ"] = "o", ["Õ"] = "o",
    ["Ô"] = "o", ["Ồ"] = "o", ["Ố"] = "o", ["Ộ"] = "o", ["Ổ"] = "o", ["Ỗ"] = "o",
    ["Ơ"] = "o", ["Ờ"] = "o", ["Ớ"] = "o", ["Ợ"] = "o", ["Ở"] = "o", ["Ỡ"] = "o",
    ["Ù"] = "u", ["Ú"] = "u", ["Ụ"] = "u", ["Ủ"] = "u", ["Ũ"] = "u",
    ["Ư"] = "u", ["Ừ"] = "u", ["Ứ"] = "u", ["Ự"] = "u", ["Ử"] = "u", ["Ữ"] = "u",
    ["Ỳ"] = "y", ["Ý"] = "y", ["Ỵ"] = "y", ["Ỷ"] = "y", ["Ỹ"] = "y",
    ["Đ"] = "d",
}

function Util.removeAccents(value)
    if value == nil then
        return ""
    end
    local s = tostring(value)
    for accented, plain in pairs(VIETNAMESE_ASCII) do
        s = s:gsub(accented, plain)
    end
    return (ko_util.stringLower and ko_util.stringLower(s)) or s:lower()
end

function Util.trim(value)
    if value == nil then
        return ""
    end
    return tostring(value):match("^%s*(.-)%s*$")
end

function Util.decodeHtml(value)
    if value == nil then
        return ""
    end
    return ko_util.htmlEntitiesToUtf8(value)
end

function Util.encodeHtml(value)
    if value == nil then
        return ""
    end
    local s = tostring(value)
    s = s:gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"):gsub('"', "&quot;"):gsub("'", "&#39;")
    return s
end

function Util.stripTags(value)
    if value == nil then
        return ""
    end

    value = value:gsub("<script[^>]*>[%s%S]-</script>", "")
    value = value:gsub("<style[^>]*>[%s%S]-</style>", "")
    value = value:gsub("<br%s*/?>", "\n")
    value = value:gsub("<BR%s*/?>", "\n")
    value = value:gsub("</p%s*>", "\n")
    value = value:gsub("</div%s*>", "\n")
    value = value:gsub("<[^>]+>", "")
    value = Util.decodeHtml(value)
    value = value:gsub("\r", "")
    value = value:gsub("[ \t]+\n", "\n")
    value = value:gsub("\n[ \t]+", "\n")
    value = value:gsub("\n\n\n+", "\n\n")
    return Util.trim(value)
end

function Util.getAttribute(tag, name)
    if tag == nil then
        return nil
    end

    local escaped_name = name:gsub("([^%w])", "%%%1")
    return tag:match(escaped_name .. '%s*=%s*"([^"]*)"')
        or tag:match(escaped_name .. "%s*=%s*'([^']*)'")
end

function Util.absoluteUrl(base_url, href)
    if not href or href == "" then
        return nil
    end
    href = Util.decodeHtml(href)
    if href:match("^https?://") then
        return href
    end
    if href:sub(1, 2) == "//" then
        return "https:" .. href
    end
    return socket_url.absolute(base_url, href)
end

function Util.withTrailingSlash(value)
    value = value:gsub("#.*$", ""):gsub("%?.*$", "")
    return value:sub(-1) == "/" and value or value .. "/"
end

function Util.safeName(value, fallback)
    value = Util.stripTags(value or "")
    if type(ko_util.sanitizeFilename) == "function" then
        value = ko_util.sanitizeFilename(value)
    else
        value = value:gsub('[<>:"/\\|?*\n\r\t]', '_')
    end
    value = value:gsub("[%c]+", " ")
    value = value:gsub("%s+", " ")
    value = Util.trim(value)
    if value == "" then
        value = fallback or "item"
    end
    if #value > 100 then
        value = value:sub(1, 100)
    end
    return value
end

function Util.urlLeaf(value, fallback)
    if not value then
        return fallback or "item"
    end
    local clean = value:gsub("#.*$", ""):gsub("%?.*$", ""):gsub("/+$", "")
    return Util.safeName(clean:match("([^/]+)$"), fallback)
end

function Util.escapeHtml(value)
    value = tostring(value or "")
    value = value:gsub("&", "&amp;")
    value = value:gsub("<", "&lt;")
    value = value:gsub(">", "&gt;")
    value = value:gsub('"', "&quot;")
    return value
end

function Util.sanitizeContentHtml(value)
    value = value or ""
    value = value:gsub("<script[^>]*>[%s%S]-</script>", "")
    value = value:gsub("<iframe[^>]*>[%s%S]-</iframe>", "")
    value = value:gsub("<ins[^>]*>[%s%S]-</ins>", "")
    value = value:gsub("<div[^>]-id=[\"']ads[^>]*>[%s%S]-</div>", "")
    value = value:gsub("%s+on[%w%-]+%s*=%s*\"[^\"]*\"", "")
    value = value:gsub("%s+on[%w%-]+%s*=%s*'[^']*'", "")
    return value
end

function Util.normalizeSearch(value)
    value = ko_util.stringLower(Util.decodeHtml(Util.stripTags(value or "")))
    for accented, plain in pairs(VIETNAMESE_ASCII) do
        value = value:gsub(accented, plain)
    end
    value = value:gsub("[^%w]+", " ")
    value = value:gsub("%s+", " ")
    return Util.trim(value)
end

function Util.searchScore(query, title, source_position)
    local normalized_query = Util.normalizeSearch(query)
    local normalized_title = Util.normalizeSearch(title)
    if normalized_query == "" or normalized_title == "" then
        return 0
    end

    local score = math.max(0, 300 - (source_position or 1))
    if normalized_title == normalized_query then
        score = score + 10000
    elseif normalized_title:sub(1, #normalized_query) == normalized_query then
        score = score + 8000
    else
        local position = normalized_title:find(normalized_query, 1, true)
        if position then
            score = score + 6000 - math.min(position, 500)
        end
    end

    local matched_tokens = 0
    local token_count = 0
    for token in normalized_query:gmatch("%S+") do
        token_count = token_count + 1
        local position = normalized_title:find(token, 1, true)
        if position then
            matched_tokens = matched_tokens + 1
            score = score + 500 - math.min(position, 200)
            if normalized_title:find(" " .. token, 1, true) then
                score = score + 100
            end
        end
    end
    if token_count > 0 then
        score = score + math.floor(2500 * matched_tokens / token_count)
    end

    score = score - math.min(#normalized_title, 300)
    return score
end

function Util.stableHash(value)
    local hash = 5381
    value = tostring(value or "")
    for index = 1, #value do
        hash = (hash * 33 + value:byte(index)) % 4294967296
    end
    return string.format("%08x", hash)
end

function Util.uniqueBy(items, key)
    local seen = {}
    local result = {}
    for _, item in ipairs(items) do
        local value = item[key]
        if value and not seen[value] then
            seen[value] = true
            table.insert(result, item)
        end
    end
    return result
end

function Util.parseGenres(html, base_url)
    local genres = {}
    for anchor_attrs, anchor_html in tostring(html or ""):gmatch(
        "<a([^>]*)>([%s%S]-)</a>"
    ) do
        local href = Util.getAttribute(anchor_attrs, "href")
        if href and href:find("/the-loai/", 1, true) then
            local name = Util.stripTags(anchor_html)
            if name ~= "" then
                table.insert(genres, {
                    name = name,
                    url = Util.absoluteUrl(base_url, href):gsub("%?.*$", ""),
                })
            end
        end
    end
    genres = Util.uniqueBy(genres, "url")
    table.sort(genres, function(left, right)
        return Util.normalizeSearch(left.name) < Util.normalizeSearch(right.name)
    end)
    return genres
end

function Util.parseGenreNames(html)
    local names = {}
    local seen = {}
    for anchor_attrs, anchor_html in tostring(html or ""):gmatch(
        "<a([^>]*)>([%s%S]-)</a>"
    ) do
        local href = Util.getAttribute(anchor_attrs, "href")
        local name = Util.stripTags(anchor_html)
        if href and href:find("/the-loai/", 1, true)
                and name ~= ""
                and not seen[name] then
            seen[name] = true
            table.insert(names, name)
        end
    end
    return names
end

function Util.getMetaContent(html, attribute, value)
    for tag in tostring(html or ""):gmatch("(<meta%s+[^>]*>)") do
        if Util.getAttribute(tag, attribute) == value then
            return Util.decodeHtml(Util.getAttribute(tag, "content"))
        end
    end
end

function Util.maxPage(html, minimum)
    local max_page = minimum or 1
    for page in tostring(html or ""):gmatch("trang%-(%d+)") do
        max_page = math.max(max_page, tonumber(page) or 1)
    end
    for page in tostring(html or ""):gmatch("page=(%d+)") do
        max_page = math.max(max_page, tonumber(page) or 1)
    end
    return max_page
end

function Util.naturalCompare(strA, strB)
    local s1 = tostring(strA or "")
    local s2 = tostring(strB or "")

    local function chunkString(str)
        local chunks = {}
        for text, number in str:gmatch("(%D*)(%d*)") do
            if text ~= "" then
                table.insert(chunks, text:lower())
            end
            if number ~= "" then
                table.insert(chunks, tonumber(number))
            end
        end
        return chunks
    end

    local c1 = chunkString(s1)
    local c2 = chunkString(s2)

    local minLen = math.min(#c1, #c2)
    for i = 1, minLen do
        local v1 = c1[i]
        local v2 = c2[i]
        if type(v1) == type(v2) then
            if v1 ~= v2 then
                return v1 < v2
            end
        else
            return type(v1) == "number"
        end
    end

    return #c1 < #c2
end

function Util.cleanChapterHtml(content)
    if not content or content == "" then return "" end
    local s = tostring(content)

    -- 1. Remove script, style, iframe, nav, header, footer elements
    s = s:gsub("<script[^>]*>[%s%S]-</script>", "")
    s = s:gsub("<style[^>]*>[%s%S]-</style>", "")
    s = s:gsub("<iframe[^>]*>[%s%S]-</iframe>", "")
    s = s:gsub("<nav[^>]*>[%s%S]-</nav>", "")

    -- 2. Remove known ad/SEO text blocks & gambling keywords
    local ad_keywords = {
        "sunwin", "kubet", "cakhia", "88bet", "go88", "b52", "hitclub", "789club",
        "fun88", "w88", "fb88", "shbet", "jun88", "hi88", "okvip", "new88", "79king", "kwin",
        "signal:", "chauchau774", "lorangeteam", "comic24h", "sanyteam", "ungtycomic",
        "navyteam", "ghientruyen", "rainbowbl",
    }

    local function isJunkLine(text)
        local lower = text:lower()
        for _, kw in ipairs(ad_keywords) do
            if lower:find(kw, 1, true) then
                return true
            end
        end
        return false
    end

    -- Filter out <p> or <div> blocks containing ad keywords
    local clean_blocks = {}
    for tag_name, attrs, inner in s:gmatch("<(p)%s*([^>]*)>([%s%S]-)</p>") do
        local plain = Util.stripTags(inner)
        if plain ~= "" and not isJunkLine(plain) and not isJunkLine(attrs) then
            table.insert(clean_blocks, "<p" .. (attrs ~= "" and (" " .. attrs) or "") .. ">" .. inner .. "</p>")
        end
    end

    if #clean_blocks > 0 then
        return table.concat(clean_blocks, "\n")
    end

    -- Fallback: line-by-line filtering if no <p> tags found
    local lines = {}
    for line in s:gmatch("[^\r\n]+") do
        local plain = Util.stripTags(line)
        if not isJunkLine(plain) then
            table.insert(lines, line)
        end
    end
    return table.concat(lines, "\n")
end

function Util.parseJson(str)
    if not str or str == "" then return nil end
    local ok_util, ko_util = pcall(require, "util")
    if ok_util and ko_util and type(ko_util.jsonDecode) == "function" then
        local ok, data = pcall(ko_util.jsonDecode, str)
        if ok and data then return data end
    end
    local ok_j, json = pcall(require, "json")
    if ok_j and json and type(json.decode) == "function" then
        local ok2, data2 = pcall(json.decode, str)
        if ok2 and data2 then return data2 end
    end
    local ok_dk, dkjson = pcall(require, "dkjson")
    if ok_dk and dkjson and type(dkjson.decode) == "function" then
        local ok3, data3 = pcall(dkjson.decode, str)
        if ok3 and data3 then return data3 end
    end
    return nil
end

return Util


