local Builder = require("truyenviet/document_builder")
local Storage = require("truyenviet/storage")

local ChapterDownloader = {}

function ChapterDownloader:listPending(source, story, chapters)
    local pending = {}
    for _, chapter in ipairs(chapters or {}) do
        if not Storage:isDownloaded(source, story, chapter) then
            table.insert(pending, chapter)
        end
    end
    return pending
end

function ChapterDownloader:cleanupPartials(source, story, chapters)
    for _, chapter in ipairs(chapters or {}) do
        os.remove(Storage:getChapterPath(source, story, chapter) .. ".part")
    end
end

function ChapterDownloader:download(source, story, chapters)
    local result = {
        downloaded = 0,
        skipped = 0,
        errors = {},
    }

    if source.kind == "comic" or type(source.getChapterAsync) ~= "function" then
        local total_chaps = chapters and #chapters or 0
        for i, chapter in ipairs(chapters or {}) do
            coroutine.yield(string.format("Đang tải %d/%d chương...", i, total_chaps))
            if Storage:isDownloaded(source, story, chapter) then
                result.skipped = result.skipped + 1
            else
                local ok, payload, fetch_err = pcall(
                    source.getChapter,
                    source,
                    chapter
                )
                if not ok then
                    fetch_err = payload
                    payload = nil
                end

                local path
                local build_err
                if payload then
                    ok, path, build_err = pcall(
                        Builder.build,
                        Builder,
                        source,
                        story,
                        chapter,
                        payload
                    )
                    if not ok then
                        build_err = path
                        path = nil
                    end
                end

                if path then
                    result.downloaded = result.downloaded + 1
                else
                    os.remove(Storage:getChapterPath(source, story, chapter) .. ".part")
                    table.insert(result.errors, string.format(
                        "%s: %s",
                        chapter.title,
                        tostring(fetch_err or build_err or "lỗi không xác định")
                    ))
                end
            end
            collectgarbage()
        end
    else
        local copas = require("copas")
        local active_downloads = 0
        local max_concurrent = source.max_concurrent or 10

        for _, chapter in ipairs(chapters or {}) do
            if Storage:isDownloaded(source, story, chapter) then
                result.skipped = result.skipped + 1
            else
                while active_downloads >= max_concurrent do
                    copas.step()
                end
                active_downloads = active_downloads + 1

                copas.addthread(function()
                    local ok, payload, fetch_err = pcall(
                        source.getChapterAsync,
                        source,
                        chapter
                    )
                    if not ok then
                        fetch_err = payload
                        payload = nil
                    end

                    local path
                    local build_err
                    if payload then
                        ok, path, build_err = pcall(
                            Builder.build,
                            Builder,
                            source,
                            story,
                            chapter,
                            payload
                        )
                        if not ok then
                            build_err = path
                            path = nil
                        end
                    end

                    if path then
                        result.downloaded = result.downloaded + 1
                        if result.downloaded == 1 and G_reader_settings and G_reader_settings.addDocument then
                            G_reader_settings:addDocument(path)
                            G_reader_settings:flush()
                        end
                    else
                        os.remove(Storage:getChapterPath(source, story, chapter) .. ".part")
                        table.insert(result.errors, string.format(
                            "%s: %s",
                            chapter.title,
                            tostring(fetch_err or build_err or "lỗi không xác định")
                        ))
                    end
                    active_downloads = active_downloads - 1
                end)
            end
            
            if active_downloads > 0 then
                copas.step(0)
            end
            coroutine.yield(string.format("Đang lấy chương... còn %d chương", active_downloads))
            collectgarbage()
        end

        while active_downloads > 0 do
            copas.step(0)
            coroutine.yield(string.format("Đang tải %d chương...", active_downloads))
        end
    end

    return result
end

return ChapterDownloader
